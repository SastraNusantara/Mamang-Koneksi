# Build APK Mamang Koneksi

Project Android Mamang Billing v1.8 dengan workflow GitHub Actions yang sudah dirapikan.

## Cara memasang ke repository GitHub

1. Ekstrak ZIP ini.
2. Buka folder `MamangBilling-Android-Project-v1.8`.
3. Unggah **seluruh isi folder tersebut** ke repository GitHub (bukan folder pembungkusnya).
4. Pastikan `settings.gradle`, `build.gradle`, `app/`, dan `.github/workflows/main.yml` berada di root repository.
5. Commit ke branch `main` atau `master`.
6. Buka tab **Actions** dan pilih **Build Mamang Koneksi APK**.
7. Setelah status hijau, buka hasil workflow dan unduh artifact **Mamang-Koneksi-APK**.

## Hasil

APK debug berada di `app/build/outputs/apk/debug/app-debug.apk` dan diunggah sebagai artifact GitHub Actions.

Workflow menggunakan JDK 17, Gradle 8.9, Android SDK 35, dan Android Gradle Plugin 8.7.3.

Catatan: APK yang dihasilkan adalah APK debug untuk instalasi/pengujian. Untuk distribusi publik atau Play Store, perlu dibuat APK/AAB release yang ditandatangani dengan keystore.

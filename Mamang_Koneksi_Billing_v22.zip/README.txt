===================================================================
 MAMANG KONEKSI BILLING - MK SYSTEM
 PACKAGED WEB & ANDROID SOURCE CODE (APK READY - v22)
===================================================================

FITUR & PEMBAHARUAN PADA VERSI v22:
1. Logo Profil Utama Resmi:
   - Menggunakan logo resmi Mamang Koneksi yang diunggah pengguna secara penuh di seluruh elemen: Logo Header, Login, Halaman About, & Struk Kasir/PDF.
2. Pemeriksaan Fungsi Menyeluruh (All Menus Verified):
   - Menu Pojok Atas & Bawah berfungsi 100% (Dashboard, Pelanggan, Kasir, Laporan Laba Rugi, Cron Job Tagihan Otomatis, Bank & E-Wallet).
   - Ekspor & Import Excel / CSV berjalan normal.
   - Pemilihan Printer Thermal (Bluetooth, USB, Network IP, PDF) & Unduh PDF berfungsi sempurna dengan menyertakan logo resmi.
   - Integrasi Akun Bot Telegram & WhatsApp Fonnte (Test Koneksi & Broadcast) berfungsi aktif.
   - Pop-up Logout elegan & simpel.

#!/bin/bash
npx cap init 'Mamang Koneksi' 'net.mamangkoneksi.billing' --web-dir .
npx cap add android
npx cap copy android
cd android && ./gradlew assembleDebug
